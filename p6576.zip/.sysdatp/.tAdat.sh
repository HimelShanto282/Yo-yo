rm -rf /storage/emulated/0/Telegram-@im_Shanto
mkdir /storage/emulated/0/Telegram-@im_Shanto
echo "≼•••🇧🇩𝐁𝐋𝐀𝐂𝐊 𝐂𝐀𝐓 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋🇧🇩 •••≽"
rm -rf  /data/data/com.rekoo.pubgm/files
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord
#dd /data/media/0/@im_Shanto
touch /data/data/com.rekoo.pubgm/files
touch /data/data/com.rekoo.pubgm/app_crashrecord
#dd /data/media/0/@im_Shanto
chmod -R 775 /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
echo "Permission 775 Successfully"
am start -n com.rekoo.pubgm/com.epicgames.ue4.SplashActivity
echo "          🇧🇩𝐒𝐔𝐂𝐂𝐄𝐒𝐒🇧🇩"
echo ""
echo "      👨‍💻𝐌𝐀𝐃𝐄 𝐁𝐘 @Im_Shanto"
echo ""
echo "≼•••🇧🇩𝐁𝐋𝐀𝐂𝐊 𝐂𝐀𝐓 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋🇧🇩 •••≽"