echo "╔═══════════════ ▓▓ ࿇  𝙵𝚞𝚌𝚔 𝚃𝚎𝚗𝚌𝚎𝚗𝚝 𝙶𝚘𝚘𝚍  ࿇ ▓▓ ═══════════════╗"
echo "◈ ━━━━━━━ ⸙ ѕhєll ѕcrípt ѕtαrt wσrkíng ⸙ ━━━━━━━ ◈ "
echo "◈ ━━━━━━━ ⸙ gαmє wíll ѕtαrt αutσmαtícαllч ⸙ ━━━━━━━ ◈"
echo " ◈ ━━━━━━━ ⸙ dσn't ѕtσp thíѕ єхєcutíσn ⸙ ━━━━━━━ ◈ "
echo "◈ ━━━━━━━ ⸙ thαnkѕ fσr єvєrчσnє ⸙ ━━━━━━━ ◈"
echo " ◈ ━━━━━━━ ⸙ whσ ѕuѕcríвєd mч prєmíum chєαtѕ ⸙ ━━━━━━━ ◈ "
echo "╚═══════════════ ▓▓ ࿇  𝙵𝚞𝚌𝚔 𝚃𝚎𝚗𝚌𝚎𝚗𝚝 𝙶𝚘𝚘𝚍  ࿇ ▓▓ ═══════════════╝"
echo ""

uptime
#====================================

rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
date
echo "ANTICRASH-GLOBAL"
sleep 1
rm -rf /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/files/tss_tmp
touch /data/data/com.tencent.ig/files/tss_tmp
touch /data/data/com.tencent.ig/app_crashrecord
chmod 000 /data/data/com.tencent.ig/files/tss_tmp
echo "Success"
echo "Aley"
date
echo "ANTICRASH-GLOBAL"
sleep 1
rm -rf /data/data/com.vng.pubgmobile/app_crashrecord
rm -rf /data/data/com.vng.pubgmobile/files/tss_tmp
touch /data/data/com.vng.pubgmobile/files/tss_tmp
touch /data/data/com.vng.pubgmobile/app_crashrecord
chmod 000 /data/data/com.vng.pubgmobile/files/tss_tmp
echo "Success"
echo "Aley"
date
echo "ANTICRASH-GLOBAL"
sleep 1
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/files/tss_tmp
touch /data/data/com.pubg.krmobile/files/tss_tmp
touch /data/data/com.pubg.krmobile/app_crashrecord
chmod 000 /data/data/com.pubg.krmobile/files/tss_tmp
echo "Success"
echo "Aley"

echo ""
echo "◈ ━━━━━━━ ⸙  clєαr lσgѕ ⸙ ━━━━━━━ ◈"
sleep 1
echo ""
echo "◈ ━━━━━━━ ⸙ ѕtαrtíng puвg mσвílє ⸙ ━━━━━━━ ◈"
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
sleep 3
echo ""
echo "◈ ━━━━━━━ ⸙ dσn't ѕtσp thíѕ єхєcutíσn ⸙ ━━━━━━━ ◈"
cleanlogs()
{
rm -rf /storage/emulated/0/.*
rm -rf /storage/emulated/0/Android/.*
rm -rf /storage/emulated/0/Android/media
rm -rf /storage/emulated/0/Android/obj
rm -rf /storage/emulated/0/Android/data/.*
rm -rf /storage/emulated/0/Android/data/bin.mt.plus
rm -rf /storage/emulated/0/amap
rm -rf /storage/emulated/0/baidu
rm -rf /storage/emulated/0/Yunai
rm -rf /storage/emulated/0/tencent
rm -rf /storage/emulated/0/Browser
rm -rf /storage/emulated/0/backups
rm -rf /storage/emulated/0/AndroLua
rm -rf /storage/emulated/0/MidasOversea
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/coverversion.ini
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs0/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs1/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Arena
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Commercial
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Download
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Chatacter
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Lab
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Mentor
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Lobby
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Login
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LoginBackUp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Notice
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Pet
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PufferDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RP
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Setting
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Store
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Chat
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Friend
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/SocialIsland
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Tables
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Task
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/UnknowPass
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Wardrobe
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/XMission
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BP_BuffGuid_Save.sav
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/loginInfoFile.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/MailPhoneLogin.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/AchievementData*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/playerprefs*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BillboardSlapData*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/personalprefs*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RecruitFilterSetting*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Sync*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/CommonSaveGame*
rm -rf /data/system/package_cache
rm -rf /data/system/graphicsstats
rm -rf /data/data/tss*
rm -rf /data/data/Room*
rm -rf /data/data/tcj*
rm -rf /data/data/Tve*
rm -rf /data/data/com.tencent.ig/app*
rm -rf /data/data/com.tencent.ig/cache
rm -rf /data/data/com.tencent.ig/code_cache
rm -rf /data/data/com.tencent.ig/no_backup
rm -rf /data/data/com.tencent.ig/shared_prefs/adjust_preferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/admob.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/APMCfg.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/BuglySdkInfos.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.AccessTokenManager.SharedPreferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.internal.preferences.APP_GATEKEEPERS.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.internal.preferences.APP_SETTINGS.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.internal.PURCHASE.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.internal.SKU_DETAILS.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.loginManager.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.sdk.appEventPreferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.sdk.attributionTracking.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.sdk.USER_SETTINGS.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.google.android.gms.appid.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.tencent.ig_preferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.twitter.sdk.android:twitter-core:session_store.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.twitter.sdk.android.AdvertisingPreferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/imsdk_unified_account.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/crashrecord.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/embryo.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/GCloudCoreSP.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/gsdk_prefs.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/HSJsonData.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/imsdk_channel.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/imsdk_settings.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/LocalNotificationPreferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/MidasOverseaIP.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/tdm.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/TencentUnipay.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/tgpa.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/WebViewChromiumPrefs.xml
sleep 1
}
PACKAGE='com.tencent.ig'
while [ $(pidof $PACKAGE) ]
do
cleanlogs
if [ ! $(pidof $PACKAGE) ]; then
break
fi
sleep 5
done
echo ""
echo "╔═══════════════ ▓▓ ࿇  𝙵𝚞𝚌𝚔 𝚃𝚎𝚗𝚌𝚎𝚗𝚝 𝙶𝚘𝚘𝚍  ࿇ ▓▓ ═══════════════╗"
echo " ◈ ━━━━━━━ ⸙ ѕhєll ѕcrípt prσjєct єхєcutíσn cσmplєtєd ⸙ ━━━━━━━ ◈ "
echo "╚═══════════════ ▓▓ ࿇  𝙵𝚞𝚌𝚔 𝚃𝚎𝚗𝚌𝚎𝚗𝚝 𝙶𝚘𝚘𝚍  ࿇ ▓▓ ═══════════════╝"
sleep 1
echo ""
echo "◈ ━━━━━━━ ⸙  clєαr lσgѕ ⸙ ━━━━━━━ ◈"
rm -rf /storage/emulated/0/.*
rm -rf /storage/emulated/0/Android/.*
rm -rf /storage/emulated/0/Android/media
rm -rf /storage/emulated/0/Android/obj
rm -rf /storage/emulated/0/Android/data/.*
rm -rf /storage/emulated/0/Android/data/bin.mt.plus
rm -rf /storage/emulated/0/amap
rm -rf /storage/emulated/0/baidu
rm -rf /storage/emulated/0/Yunai
rm -rf /storage/emulated/0/tencent
rm -rf /storage/emulated/0/Browser
rm -rf /storage/emulated/0/backups
rm -rf /storage/emulated/0/AndroLua
rm -rf /storage/emulated/0/MidasOversea
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Content
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/coverversion.ini
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs0/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferEifs1/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Activity
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Arena
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Commercial
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Download
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Chatacter
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Lab
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Mentor
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Loading
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Lobby
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LobbyBubble
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Login
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/LoginBackUp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Notice
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Pet
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PufferDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RP
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Season
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Setting
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Store
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Chat
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Friend
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/PersonSpace
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/SocialIsland
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Tables
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Task
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/UnknowPass
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Wardrobe
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/XMission
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BP_BuffGuid_Save.sav
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/loginInfoFile.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/MailPhoneLogin.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/AchievementData*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/playerprefs*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/BillboardSlapData*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/personalprefs*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/RecruitFilterSetting*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Sync*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/CommonSaveGame*
rm -rf /data/system/package_cache
rm -rf /data/system/graphicsstats
rm -rf /data/data/tss*
rm -rf /data/data/Room*
rm -rf /data/data/tcj*
rm -rf /data/data/Tve*
rm -rf /data/data/com.tencent.ig/app*
rm -rf /data/data/com.tencent.ig/cache
rm -rf /data/data/com.tencent.ig/code_cache
rm -rf /data/data/com.tencent.ig/no_backup
rm -rf /data/data/com.tencent.ig/shared_prefs/adjust_preferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/admob.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/APMCfg.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/BuglySdkInfos.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.AccessTokenManager.SharedPreferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.internal.preferences.APP_GATEKEEPERS.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.internal.preferences.APP_SETTINGS.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.internal.PURCHASE.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.internal.SKU_DETAILS.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.loginManager.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.sdk.appEventPreferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.sdk.attributionTracking.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.facebook.sdk.USER_SETTINGS.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.google.android.gms.appid.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.google.android.gms.measurement.prefs.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.tencent.ig_preferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.twitter.sdk.android:twitter-core:session_store.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/com.twitter.sdk.android.AdvertisingPreferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/imsdk_unified_account.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/crashrecord.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/embryo.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/GCloudCoreSP.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/gsdk_prefs.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/HSJsonData.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/imsdk_channel.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/imsdk_settings.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/LocalNotificationPreferences.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/MidasOverseaIP.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/tdm.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/TencentUnipay.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/tgpa.xml
rm -rf /data/data/com.tencent.ig/shared_prefs/WebViewChromiumPrefs.xml
sleep 1
echo ""
echo "╔═══════════════ ▓▓ ࿇  𝙵𝚞𝚌𝚔 𝚃𝚎𝚗𝚌𝚎𝚗𝚝 𝙶𝚘𝚘𝚍  ࿇ ▓▓ ═══════════════╗"
echo " ◈ ━━━━━━━ ⸙ ѕhєll ѕcrípt prσjєct єхєcutíσn cσmplєtєd ⸙ ━━━━━━━ ◈ "
echo "╚═══════════════ ▓▓ ࿇  𝙵𝚞𝚌𝚔 𝚃𝚎𝚗𝚌𝚎𝚗𝚝 𝙶𝚘𝚘𝚍  ࿇ ▓▓ ═══════════════╝"