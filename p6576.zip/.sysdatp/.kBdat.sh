echo "≼•••🇧🇩𝐁𝐋𝐀𝐂𝐊 𝐂𝐀𝐓 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋🇧🇩 •••≽"
#dd /data/media/0/@im_Shanto
chmod -R 775 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
echo "Permission 775 Successfully"
#dd /data/media/0/@im_Shanto
echo "          🇧🇩𝐒𝐔𝐂𝐂𝐄𝐒𝐒🇧🇩"
echo ""
echo "      👨‍💻𝐌𝐀𝐃𝐄 𝐁𝐘 @Im_Shanto"
echo ""
echo "≼•••🇧🇩𝐁𝐋𝐀𝐂𝐊 𝐂𝐀𝐓 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋🇧🇩 •••≽"
